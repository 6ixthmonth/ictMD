package com.sesoc.ictmd.Interface;

import com.sesoc.ictmd.vo.ModelBase;

public interface ModelBaseDAO {

	public ModelBase searchModelBase(String searchKeyword);
	
}
